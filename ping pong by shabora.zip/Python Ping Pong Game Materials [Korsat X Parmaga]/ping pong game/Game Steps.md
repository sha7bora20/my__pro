# Korsat X Parmaga (Youtube Channel)

## Game Steps:

> 1.  Setup Window & Game Loop

> 2.  Setup Game Objects

- ball
- player 1
- player 2
- center line
- score

> 3.  Key Bindings and Players Movement

- player 1 movement Functions
- player 2 movement Functions
- get user inputs

> 4.  Game Loop and Interactions

- ball movement
- ball & borders collision
- ball & players collision
- score handling
